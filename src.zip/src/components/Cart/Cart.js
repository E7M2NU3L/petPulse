import React from 'react'
import CartContent from './utils/CartContent'
import CartNote from './utils/CartNote'
import SearchBar from './utils/SearchBar'

const Cart = () => {
  return (
    <div>
        <SearchBar />
        <CartContent />
        <CartNote />
    </div>
  )
}

export default Cart