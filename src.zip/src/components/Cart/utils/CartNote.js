import React from 'react'

const CartNote = () => {
  return (
    <div>CartNote</div>
  )
}

export default CartNote